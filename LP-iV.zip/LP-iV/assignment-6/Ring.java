import java.util.Arrays;
import java.util.Scanner;

public class Ring {
    public static void main(String[] args) {
        Rr[] proc;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of process:");
        int num = in.nextInt();
        proc = new Rr[num];

        for (int i = 0; i < num; i++) {
            proc[i] = new Rr();
            proc[i].index = i;
            System.out.println("Enter the id of process:");
            proc[i].id = in.nextInt();
            proc[i].state = "active";
            proc[i].f = 0;
        }

        Arrays.sort(proc, (p1, p2) -> Integer.compare(p1.id, p2.id));

        for (int i = 0; i < num; i++) {
            System.out.print("[" + i + "] " + proc[i].id + " ");
        }

        proc[num - 1].state = "inactive";
        System.out.println("\nProcess " + proc[num - 1].id + " selected as coordinator");

        while (true) {
            System.out.println("\n1. Election 2. Quit");
            int ch = in.nextInt();

            for (int i = 0; i < num; i++) {
                proc[i].f = 0;
            }

            switch (ch) {
                case 1:
                    System.out.println("\nEnter the process number that initialized the election:");
                    int init = in.nextInt();
                    int temp2 = init;
                    int temp1 = init + 1;
                    int i = 0;

                    while (temp2 != temp1) {
                        if ("active".equals(proc[temp1].state) && proc[temp1].f == 0) {
                            System.out.println("\nProcess " + proc[init].id + " sends a message to " + proc[temp1].id);
                            proc[temp1].f = 1;
                            init = temp1;
                            i++;
                        }

                        temp1 = (temp1 == num) ? 0 : temp1 + 1;
                    }

                    System.out.println("\nProcess " + proc[init].id + " sends a message to " + proc[temp1].id);
                    int[] arr = new int[i + 1];
                    arr[i] = proc[temp1].id;
                    int max = -1;

                    for (int j = 0; j < i; j++) {
                        if (max < arr[j]) {
                            max = arr[j];
                        }
                    }

                    System.out.println("\nProcess " + max + " selected as coordinator");

                    for (int k = 0; k < num; k++) {
                        if (proc[k].id == max) {
                            proc[k].state = "inactive";
                        }
                    }
                    break;
                case 2:
                    System.out.println("Program terminated...");
                    in.close();
                    return;
                default:
                    System.out.println("\nInvalid response\n");
                    break;
            }
        }
    }
}

class Rr {
    public int index;
    public int id;
    public int f;
    public String state;
}
